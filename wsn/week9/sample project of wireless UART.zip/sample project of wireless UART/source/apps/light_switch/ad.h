#ifndef __AD_H__
#define __AD_H__
//macro
//#define uint8 unsigned char
//#define uint  unsigned int

#define FAN P1_3
extern void AD_init(void);
extern unsigned short get_vol(void);

#endif