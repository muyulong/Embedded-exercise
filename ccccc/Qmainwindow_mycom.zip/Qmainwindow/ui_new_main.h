/********************************************************************************
** Form generated from reading UI file 'new_main.ui'
**
** Created: Fri Apr 30 23:50:21 2021
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_MAIN_H
#define UI_NEW_MAIN_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStatusBar>
#include <QtGui/QTextBrowser>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_new_main
{
public:
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_9;
    QTextBrowser *textBrowser;
    QSpacerItem *horizontalSpacer_4;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *portNameComboBox;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *baudRateComboBox;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QComboBox *dataBitsComboBox;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QComboBox *parityComboBox;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QComboBox *stopBitsComboBox;
    QSpacerItem *verticalSpacer_6;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *openMyComBtn;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *closeMyComBtn;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *saveMyComBtn;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_8;
    QLineEdit *sendMsgLineEdit;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer;
    QPushButton *sendMsgBtn;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_clear;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *verticalSpacer_7;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *new_main)
    {
        if (new_main->objectName().isEmpty())
            new_main->setObjectName(QString::fromUtf8("new_main"));
        new_main->resize(617, 628);
        centralWidget = new QWidget(new_main);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 591, 541));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        textBrowser = new QTextBrowser(layoutWidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        horizontalLayout_9->addWidget(textBrowser);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_4);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        portNameComboBox = new QComboBox(layoutWidget);
        portNameComboBox->setObjectName(QString::fromUtf8("portNameComboBox"));

        horizontalLayout->addWidget(portNameComboBox);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        baudRateComboBox = new QComboBox(layoutWidget);
        baudRateComboBox->setObjectName(QString::fromUtf8("baudRateComboBox"));

        horizontalLayout_2->addWidget(baudRateComboBox);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        dataBitsComboBox = new QComboBox(layoutWidget);
        dataBitsComboBox->setObjectName(QString::fromUtf8("dataBitsComboBox"));

        horizontalLayout_3->addWidget(dataBitsComboBox);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        parityComboBox = new QComboBox(layoutWidget);
        parityComboBox->setObjectName(QString::fromUtf8("parityComboBox"));

        horizontalLayout_4->addWidget(parityComboBox);


        verticalLayout->addLayout(horizontalLayout_4);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_5);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        stopBitsComboBox = new QComboBox(layoutWidget);
        stopBitsComboBox->setObjectName(QString::fromUtf8("stopBitsComboBox"));

        horizontalLayout_5->addWidget(stopBitsComboBox);


        verticalLayout->addLayout(horizontalLayout_5);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_6);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        openMyComBtn = new QPushButton(layoutWidget);
        openMyComBtn->setObjectName(QString::fromUtf8("openMyComBtn"));

        horizontalLayout_6->addWidget(openMyComBtn);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);

        closeMyComBtn = new QPushButton(layoutWidget);
        closeMyComBtn->setObjectName(QString::fromUtf8("closeMyComBtn"));

        horizontalLayout_6->addWidget(closeMyComBtn);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_6);

        saveMyComBtn = new QPushButton(layoutWidget);
        saveMyComBtn->setObjectName(QString::fromUtf8("saveMyComBtn"));

        horizontalLayout_6->addWidget(saveMyComBtn);


        verticalLayout->addLayout(horizontalLayout_6);


        horizontalLayout_9->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout_9);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        sendMsgLineEdit = new QLineEdit(layoutWidget);
        sendMsgLineEdit->setObjectName(QString::fromUtf8("sendMsgLineEdit"));

        horizontalLayout_8->addWidget(sendMsgLineEdit);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer);

        sendMsgBtn = new QPushButton(layoutWidget);
        sendMsgBtn->setObjectName(QString::fromUtf8("sendMsgBtn"));

        horizontalLayout_7->addWidget(sendMsgBtn);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_2);

        pushButton_clear = new QPushButton(layoutWidget);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));

        horizontalLayout_7->addWidget(pushButton_clear);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_5);


        horizontalLayout_8->addLayout(horizontalLayout_7);


        verticalLayout_2->addLayout(horizontalLayout_8);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_7);

        new_main->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(new_main);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 617, 30));
        new_main->setMenuBar(menuBar);
        mainToolBar = new QToolBar(new_main);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        new_main->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(new_main);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        new_main->setStatusBar(statusBar);

        retranslateUi(new_main);
        QObject::connect(pushButton_clear, SIGNAL(clicked()), textBrowser, SLOT(clear()));

        QMetaObject::connectSlotsByName(new_main);
    } // setupUi

    void retranslateUi(QMainWindow *new_main)
    {
        new_main->setWindowTitle(QApplication::translate("new_main", "MainWindow", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("new_main", "\344\270\262\345\217\243\351\200\211\346\213\251", 0, QApplication::UnicodeUTF8));
        portNameComboBox->clear();
        portNameComboBox->insertItems(0, QStringList()
         << QApplication::translate("new_main", "COM1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "COM2", 0, QApplication::UnicodeUTF8)
        );
        label_2->setText(QApplication::translate("new_main", "\346\263\242\347\211\271\347\216\207", 0, QApplication::UnicodeUTF8));
        baudRateComboBox->clear();
        baudRateComboBox->insertItems(0, QStringList()
         << QApplication::translate("new_main", "9600", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "38400", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "115200", 0, QApplication::UnicodeUTF8)
        );
        label_3->setText(QApplication::translate("new_main", "\346\225\260\346\215\256\344\275\215", 0, QApplication::UnicodeUTF8));
        dataBitsComboBox->clear();
        dataBitsComboBox->insertItems(0, QStringList()
         << QApplication::translate("new_main", "5", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "6", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "7", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("new_main", "8", 0, QApplication::UnicodeUTF8)
        );
        label_4->setText(QApplication::translate("new_main", "\345\245\207\345\201\266\346\240\241\351\252\214", 0, QApplication::UnicodeUTF8));
        parityComboBox->clear();
        parityComboBox->insertItems(0, QStringList()
         << QApplication::translate("new_main", "\346\227\240", 0, QApplication::UnicodeUTF8)
        );
        label_5->setText(QApplication::translate("new_main", "\345\201\234\346\255\242\344\275\215", 0, QApplication::UnicodeUTF8));
        stopBitsComboBox->clear();
        stopBitsComboBox->insertItems(0, QStringList()
         << QApplication::translate("new_main", "1", 0, QApplication::UnicodeUTF8)
        );
        openMyComBtn->setText(QApplication::translate("new_main", "\346\211\223\345\274\200\347\252\227\345\217\243", 0, QApplication::UnicodeUTF8));
        closeMyComBtn->setText(QApplication::translate("new_main", "\345\205\263\351\227\255\347\252\227\345\217\243", 0, QApplication::UnicodeUTF8));
        saveMyComBtn->setText(QApplication::translate("new_main", "\344\277\235\345\255\230\351\205\215\347\275\256", 0, QApplication::UnicodeUTF8));
        sendMsgBtn->setText(QApplication::translate("new_main", "\345\217\221\351\200\201\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        pushButton_clear->setText(QApplication::translate("new_main", "\346\270\205\351\231\244", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class new_main: public Ui_new_main {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_MAIN_H
