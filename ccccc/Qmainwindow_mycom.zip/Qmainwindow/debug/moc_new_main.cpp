/****************************************************************************
** Meta object code from reading C++ file 'new_main.h'
**
** Created: Sat May 1 00:29:31 2021
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../new_main.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'new_main.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_new_main[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x08,
      36,    9,    9,    9, 0x08,
      63,    9,    9,    9, 0x08,
      87,    9,    9,    9, 0x08,
      99,    9,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_new_main[] = {
    "new_main\0\0on_openMyComBtn_clicked()\0"
    "on_closeMyComBtn_clicked()\0"
    "on_sendMsgBtn_clicked()\0readMyCom()\0"
    "on_saveMyComBtn_clicked()\0"
};

const QMetaObject new_main::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_new_main,
      qt_meta_data_new_main, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &new_main::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *new_main::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *new_main::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_new_main))
        return static_cast<void*>(const_cast< new_main*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int new_main::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_openMyComBtn_clicked(); break;
        case 1: on_closeMyComBtn_clicked(); break;
        case 2: on_sendMsgBtn_clicked(); break;
        case 3: readMyCom(); break;
        case 4: on_saveMyComBtn_clicked(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
